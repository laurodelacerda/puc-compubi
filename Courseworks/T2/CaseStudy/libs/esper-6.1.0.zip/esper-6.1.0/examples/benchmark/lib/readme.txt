Drop jars in this folder to have them take into account for the build and run classpath
(esper, log4j, slf4j, antlr, cglib jars)

You can also drop additionnal jars.

If you are running the benchmark project from an esper svn checkout, you can leave this folder empty. The build and run will be made against the compiled esper you have in the esper/ module.