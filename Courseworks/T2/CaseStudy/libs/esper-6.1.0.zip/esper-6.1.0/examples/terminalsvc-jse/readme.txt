REQUIREMENTS
*************************************
Java 5 (JAVA_HOME set etc)
Ant (tested with Ant 1.6.5)

HOW TO
*************************************
You need to get Esper from http://www.espertech.com/esper
and copy Esper runtime jars in <project>/lib
Simply use the Ant <project>/build.xml to run the example
>ant
// it should compile and run, print out terminal event generated for simulation
// and output complex composite events

Look at the code, especially start with
com.espertech.esper.example.terminal.jse.simulate.TerminalEventSimulator 


GETTING Esper
*************************************
http://www.espertech.com/esper/evaluating/download/download.html

Esper Documentation
*******************
http://www.espertech.com/esper

